command = ""

while command != "QUIT":
    command = input(">>> ").upper()
    if command == "START":
        print("Car Started...")
    elif command == "STOP":
        print("Car Stopped...")
    elif command == "HELP":
        print("""
Start - To Start the car.
Stop - To Stop the car.
Quit - To Quit.
        """)
    else:
        print("Sorry, I don't understand that...")
else:
    print("Exit From Car...")
