'''
birth_year = int(input("Birth year: "))
print(type(birth_year))
name = input("My name is: ")
print(type(name))
age = int(2020) - birth_year
print(type(age))
print(name + " is " + str(age) + " years old.")
'''

weight_pound = int(input("Weight in pound: "))
weight_kg = weight_pound * 0.45
print("Your weight in kg is " + str(weight_kg))