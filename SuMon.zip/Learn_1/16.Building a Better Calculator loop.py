cont = "y"
while cont.lower() == "y":

    num1 = int(input("Enter first number: "))
    print("Enter a Operator: ")
    op = input(" ")
    num2 = int(input("Enter second number: "))

    if op == "+":
        print(num1 + num2)
    elif op == "-":
        print(num1 - num2)
    elif op == "*":
        print(num1 * num2)
    elif op == "/":
        print(num1 / num2)
    else:
        print("Invalid operator")
    cont = input("Continue?y/n:")
    if cont == "n":
        break