
number_grid = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [0]
]
print(number_grid[0][0]) #[r][c]
print(number_grid[0][1]) #[r][c]
print(number_grid[1][2]) #[r][c]
print(number_grid[2][2]) #[r][c]
print(number_grid[3][0]) #[r][c]
print("_______________________")

for row in number_grid:
    print(row)
print("_______________________")

for row in number_grid:
    for col in row:
        print(col)
print("_______________________")

for col in number_grid:
    for row in col:
        print(row)
print("_______________________")