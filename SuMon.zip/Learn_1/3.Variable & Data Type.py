'''
character_name = "SuMon"
print(character_name.lower())
character_age = "21"
character_num = 70
is_male = False
print("There once was a man named " + character_name + ", ")
print("he was " + character_age + " years old. ")
character_name = "Mike"
print("He really liked the name " + character_name + ", ")
print("but didn't like being " + str(character_num) + ".")
'''


#MOSH
price = 10   #integer
rating = 4.9    #float
name = 'SuMon'  #string
is_published = True     #Boolean
print(price)        #print_out

name = 'John Smith'
age = 20
is_new = True
print("We check in a patient named " + name + ".")
print("He's " + str(age) + " years old and is a new patient" )