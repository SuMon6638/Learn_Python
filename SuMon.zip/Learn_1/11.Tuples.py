coordinates = (4, 5)
print(coordinates[1])
print(coordinates[0])

coordinates = [(4, 5), (6,7), (80,34)]
print(coordinates[1])
print(coordinates[0])
coordinates[1]  = 10
print(coordinates[1])
coordinates[1]  = (10, 15)
print(coordinates[1])

print(coordinates)