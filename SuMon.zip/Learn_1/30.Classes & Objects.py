from Student_30 import Student

student1 =  Student("Sumon", "Computer Engineering", 3.9, False)
student2 =  Student("Anik", "Civil Engineering", 2.9, True)

print(student1.name)
print(student1.major)
print(student1.gpa)
print(student1.is_on_probation)

print("_________________")
print(student2.name)
print(student2.major)
print(student2.gpa)
print(student2.is_on_probation)

