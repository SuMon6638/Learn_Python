

employee_file = open("employees.txt", "a")

employee_file.write("\nKelly- Customer Service")

employee_file.close()