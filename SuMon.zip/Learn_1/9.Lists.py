friends = ["Shumon", "Anik", "Amit", "Mohsin", "Pabel", "Sajid"]
        #      0       1       2        3         4         5
        #     -6      -5      -4       -3        -2        -1
print(friends)
print(friends[1])
print(friends[0])
print(friends[2])
print(friends[5])
print(friends[-1])
print(friends[-2])
print(friends[-6])
print(friends[2:]) #Show from 2 to last index
print(friends[4:]) #Show from 4 to last index
print(friends[1:3]) #Show from 1 to before 3
print(friends[1:4]) ##Show from 1 to before 4
friends[1] = "Joynal"
print(friends[1])
friends = ["Shumon", 2, False]
print(friends)

print(friends.index("Shumon"))