#Logical "AND" Operators
high_income = True
good_credit = True

if high_income and good_credit:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")

high_income = True
good_credit = False

if high_income and good_credit:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")

#Logical "OR" Operator:

high_income = True
good_credit = False

if high_income or good_credit:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")

high_income = False
good_credit = False

if high_income and good_credit:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")


#Logical "NOT" Operators

good_credit = True
criminal_record = False

if good_credit and not criminal_recordc:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")


good_credit = True
criminal_record = False

if good_credit and not criminal_recordc:
    print("Eligible for loan.")
else:
    print("Not eligible for loan")
print("________________________")