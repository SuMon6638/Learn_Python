class Question:
    def __int__(self, prompt, answer):
        self.promt = promt
        self.answer = answer