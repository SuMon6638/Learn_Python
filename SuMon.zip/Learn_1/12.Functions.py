def SuMon():
    print("Hello User")
    print(2+5)
    print("End of this function.")

print("Top")
SuMon()
print("Bottom")
#Here SuMon is a function
       #where we put some code..
#After that when in any line
      #if we call this function by his name..
#Then it will show the code of this function.


def SuM_on(name, age):
    print("Hello dear " + name + ", you are " + age + ".")
SuM_on("Honey", "18a")
SuM_on("Sumon", "21")
SuM_on("Modhu", "18")


def SuM_on(name, age):
    print("Hello " + name + ", you are " + str(age) + ".")
SuM_on("Honey", 18)
SuM_on("Sumon", 21)
SuM_on("Modhu", 18)


