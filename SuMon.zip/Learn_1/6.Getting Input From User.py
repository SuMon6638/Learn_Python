'''
name = input("Enter your name: ")
age = input("Enter your name: ")
print("Hello " + name + "! You are " + age + ".")
'''

#Mosh

name = input("What is your name? ")
print("Hi " + name)

name = input("What is yout name? ")
color = input("What is yout favourite color? ")
print(name + " likes " + color)