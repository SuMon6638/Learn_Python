x = 10 + 3 * 2
print(x)

y = 10 + 3 * 2 ** 2
print(y)

z = (2 + 3) * 10 - 3
print(z)

'''
Mathematical Operations Priority:
parenthesis---Bracket
exponentiation 2**3
multiplication or division
addition or substraction
'''