cont = "y"
while cont.lower() == "y":

    num1 = float(input("Enter first number: "))
    op = input("Enter Operator: ")
    num2 = float(input("Enter second number: "))

    if op == "+":
        print(num1 + num2)
    elif op == "-":
        print(num1 - num2)
    elif op == "*":
        print(num1 * num2)
    elif op == "/":
        print(num1 / num2)
    else:
        print("Invalid operator")
    cont = input("Do you want to Continue?y/n:")
    if cont == "n":
        break