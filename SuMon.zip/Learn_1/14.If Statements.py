'''
is_male = True
if is_male:
    print("You are a male.")
else:
    print("You are not a male")


is_male = False
if is_male:
    print("You are a male.")
else:
    print("You are not a male")
print("1_____________________________")


is_male = True
is_tall = True

if is_male or is_tall:
    print("You are a male or tall or both.")
else:
    print("You neither male nor tall")


is_male = True
is_tall = False

if is_male or is_tall:
    print("You are a male or tall or both.")
else:
    print("You neither male nor tall")


is_male = False
is_tall = True

if is_male or is_tall:
    print("You are a male or tall or both.")
else:
    print("You neither male nor tall")


is_male = False
is_tall = False

if is_male or is_tall:
    print("You are a male or tall or both.")
else:
    print("You neither male nor tall")
print("2_____________________________")



is_male = True
is_tall = True

if is_male and is_tall:
    print("You are a tall male.")
else:
    print("You are either not male or not tall or both")


is_male = False
is_tall = True

if is_male and is_tall:
    print("You are a tall male.")
elif is_male:
    print("You are a male, But not tall.")
elif is_tall:
    print("You are tall, But not male.")
else:
    print("You are either not male and not tall")


is_male = False
is_tall = True

if is_male and is_tall:
    print("You are a tall male.")
else:
    print("You are either not male or not tall or both")


is_male = False
is_tall = False

if is_male and is_tall:
    print("You are a tall male.")
else:
    print("You are not male or not tall or both")
print("3_____________________________")



is_male = False
is_tall = True

if is_male and is_tall:
    print("You are a tall male.")
elif is_male and not(is_tall):
    print("You are a short male")
elif not is_male and not(is_tall):
    print("You are not a male not tall")
elif is_tall and not(is_male):
    print("You are tall but not male")
else:
    print("You are either not male or not tall or both")


is_male = True
is_tall = False

if is_male and is_tall:
    print("You are a tall male.")
elif is_male and not(is_tall):
    print("You are a short male")
elif not is_male and is_tall:
    print("You are not a male but are tall")
else:
    print("You are either not male or not tall or both")


is_male = False
is_tall = True

if is_male and is_tall:
    print("You are a tall male.")
elif is_male and not(is_tall):
    print("You are a short male")
elif not is_male and is_tall:
    print("You are not a male but are tall")
else:
    print("You are either not male or not tall or both")


is_male = False
is_tall = False

if is_male and is_tall:
    print("You are a tall male.")
elif is_male and not(is_tall):
    print("You are a short male")

else:
    print("You are not male or not tall")
print("4_____________________________")
'''


'''
#Mosh

is_hot = True

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
else:
    print("It's a cold day")
    print("Wear warm clothes")
print("Enjoy your day")
print("______________________")

is_hot = False

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
else:
    print("It's a cold day")
    print("Wear warm clothes")
print("Enjoy your day")
print("______________________")


is_hot = False
is_cold = True

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
elif is_cold:
    print("It's a cold day")
    print("Wear warm clothes")
else:
    print("Enjoy your day")
print("______________________")

is_hot = True
is_cold = False

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
elif is_cold:
    print("It's a cold day")
    print("Wear warm clothes")
else:
    print("Enjoy your day")
print("______________________")


is_hot = False
is_cold = False

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
elif is_cold:
    print("It's a cold day")
    print("Wear warm clothes")
else:
    print("Enjoy your day")
print("______________________")


is_hot = True
is_cold = True

if is_hot:
    print("It's a hot day")
    print("Drink plenty of water")
elif is_cold:
    print("It's a cold day")
    print("Wear warm clothes")
else:
    print("Enjoy your day")
print("______________________")


'''


#Excercise:

is_good_credit = True

if is_good_credit:
    print("They need to put down 20%")
else:
    print("They need to put down 10%")
print("They need to put down 10%")



price = 1000000
good_cre = True
if good_cre > price:
    down_payment = 0.1 * price
else:
    down_payment = 0.2 * price
print(f"Down payment: ${down_payment}")


price = 1000000
good_cre = True
if good_cre:
    down_payment = 0.1 * price
else:
    down_payment = 0.2 * price
print(f"Down payment: ${down_payment}")

