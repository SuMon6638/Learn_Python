'''
phrase = "SuMonur Rahman"
         #0123456789....
print(phrase + " is cool")
print(phrase.lower())
print(phrase.upper())
print(phrase.isupper())
# If the word is written by capital letter
# then it show true other wise it show false.
print(phrase.upper().isupper())
print(phrase.islower())
print(phrase.lower().islower())
print(len(phrase))
print(phrase[0])
print(phrase[5])
print(phrase.upper()[12])
print(phrase.index("M"))
print(phrase.index("o"))
print(phrase.index("n"))
print(phrase.upper().index("U"))
print(phrase.index("Rahm"))
print(phrase.replace("SuMonur", "Abdur"))

print("Sumonur Rahman. \nI want to be a freelancer.")
print("Sumonur Rahman. I want to be \na \"freelancer\".")
'''



#Mosh

course = "Python's Course for Beginners"
course1 = 'Python for "Beginners"'
print(course)
print(course1)

print(course[0])
print(course[1])
print(course[-1])
print(course[-2])
print(course[0:3])
print(course[0:])
print(course[1:])
print(course[:5])
print(course[:])

another = course[:]
print(another)
another1 = course[2:5]
print(another1)

#Formatted_String

first = 'John'
last = 'Smith'

print(first + " [" + last + "] is a coder.")

msg = f'{first} [{last}] is a coder.'   #it's called format string.
print(msg)

#String_Method
print(len(course))

print(course.upper())
print(course)
print(course.isupper())
print(course.upper().isupper())
print(course.lower())
print(course)
print(course.islower())
print(course.lower().islower())
print(course.index('P'))
print(course.index('o'))

print(course.find('P'))
print(course.find('o'))
print(course.find('Beg'))

print(course.replace('Beginners', 'Advance'))

print('Python' in course)
print('python' in course)
print(course.title())   #1st alphabet of every word in a sentence convert into uppercase.
