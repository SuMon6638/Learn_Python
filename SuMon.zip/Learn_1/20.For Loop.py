
friends = ["Jim", "Karen", "Kevin"]
for letter in "SuMon's Academy":
    print(letter)
print("___________________")

for friend in friends:
    print(friend)
print("___________________")

for name in friends:
    print(name)
print("___________________")

for index in range(10):
    print(index)
print("___________________")

for index in range(3, 10): #1st to before last
    print(index)
print("___________________")

for index in range(len(friends)):
    print(friends[index])
    friends[2]
print("___________________")

for index in range(5):
    if index == 0:
        print("first Iteration")
    else:
        print("Not first")
print("___________________")

for index in range(5):
    if index == 2:
        print("first Iteration")
    else:
        print("Not first")