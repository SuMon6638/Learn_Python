from math import *          #or "import math"


my_num=-5
print(str(my_num) + " is my favourite number")
print(abs(my_num))

print(2)
print(2.54475646)
print(-2.54475646)
print(abs(-2.9475646))
print(3*5)
print(3*5.6545)
print(3+5)
print(3/5)
print(3*4+5)
print(3*(4+5))
print(10 % 3) #ভাগশেষ দেখাবে
print(pow(4, 6)) #প্রথমটি Base 2nd টি Power
print(max(4, 6))
print(min(4, 6))
print(round(5.3)) #নিকটস্থ পূর্ণসংখ্যা --৫
print(round(5.8)) #নিকটস্থ পূর্ণসংখ্যা --৬
print(floor(7.3)) #দশমিক এর পরের অংশ বাদ --৭
print(floor(7.8)) #দশমিক এর পরের অংশ বাদ --৭
print(ceil(8.3)) #পূর্ণসংখ্যাটির পরের সংখ্যা --৯
print(ceil(8.8)) #পূর্ণসংখ্যাটির পরের সংখ্যা --৯
print(sqrt(36)) #বর্গমূল করবে