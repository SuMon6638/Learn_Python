import calendar
print(calendar.month(2020, 5))
R = float(input("Enter the radius of circle: "))
A = float(3.14159 * R * R)
print("A=%0.2f" % A)

PC1 = int(input())
P1U = int(input())
P1Pr = float(input())
P1T = float(P1U * P1Pr)

PC2 = int(input())
P2U = int(input())
P2Pr = float(input())
P2T = float(P2U * P2Pr)

Bill = float(P1T + P2T)

print("VALOR A PAGAR: R$ %.2f" % Bill)

print(16 * 5)

tuple = ("abcd", 786, 2.23, "John", 70.2)
list = ["abcd", 786, 2.23, "John", 70.2]
print(tuple[2])
list[2] = 1000
print (list)
