

#employee_file = open("employees1.txt", "w")
employee_file = open("index.html", "w")
#employee_file.write("\nKelly - Customer Service")
employee_file.write("<p>This is HTML</p>")
employee_file.close()