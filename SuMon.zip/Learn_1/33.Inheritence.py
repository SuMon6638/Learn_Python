from Chef_33 import Chef
from ChineseChef_33 import ChineseChef

myChef = Chef()
myChef.make_chicken()
myChef.make_salad()
myChef.make_special_dish()

print("___________________")
myChinesechef = ChineseChef()
myChinesechef.make_chicken()
myChinesechef.make_salad()
myChinesechef.make_special_dish()
myChinesechef.make_fried_rice()
myChinesechef.make_chicken()