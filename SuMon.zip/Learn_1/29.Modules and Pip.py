import useful_tools_29
import docx

print(useful_tools_29.roll_dice(10))

docx.

#Extended Definitions-Lib-Site_packages-docx
