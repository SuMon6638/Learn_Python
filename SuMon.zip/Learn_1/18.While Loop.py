'''
i = 0
while i <= 10:
    print(i)
    i = i + 1 #or i += 1

print("Done with loop")

'''

#Mosh

'''
    while condition:
        ....
'''

i = 1
while i <= 5:
    print(i)
    i = i + 1
print("Done")

i = 1
while i <= 5:
    print('*' * i)
    i = i + 1
print("Done")