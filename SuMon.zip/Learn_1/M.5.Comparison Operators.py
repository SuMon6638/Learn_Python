temperature = 35

if temperature > 30:        #"<"  "<="  ">="  "=="  "!="
    print("It's a hot day.")
else:
    print("It's not a hot day.")


#Exercise:

name = input("Enter Your name: ")

if len(name) < 3:
    print("Name must be at least 3 character.")
elif len(name) > 50:
    print("Name can be maximum of 50 character.")
else:
    print("Name looks good!")