lucky_number=[4, 8, 15, 16, 23, 42]
lucky_number2=[48, 15, 8, 16, 23, 42]
friends = ["Kevin", "Karen", "Karen", "Jim", "Ashik", "Oscar"]
print(friends)

friends.sort() #Word gulo Alphabetically Sajabe
print(friends)

print(friends.index("Karen")) #Position of these word in friends.
                    #If there have 2same word then first one will be show.

print(friends.count("Karen")) #Some of how many Karen in friends

friends.extend(lucky_number) #Insert lucky number after the friends item.
print(friends)

friends.append("Creed") #Insert this after the last element
print(friends)

friends.insert(1, "SuMon") #Insert SuMon in index 1
print(friends)

friends.remove("Jim") #Remove jim from friends
print(friends)

friends.pop() #Remove the last element
print(friends)

friends2 = friends.copy()
print(friends2) #Same element off friends

lucky_number2.reverse() #Number gulo ulto vabe sajabe but serially korbe na.
print(lucky_number2)
lucky_number2.sort() #Number gulo serially sajabe. Small to BIG
print(lucky_number2)

friends.clear() #Remove all the element from friends.
print(friends)