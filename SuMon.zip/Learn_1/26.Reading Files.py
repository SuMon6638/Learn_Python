

'''
r - only read
w - write -- It's erase the all of older data and add new data.
a - append_Modify_Change_Add--Adding some text at the end of the file
r+ - reading and writing
'''
employee_file = open("employees.txt", "r")

#print(employee_file.readable()) # true when "r" false wher "w"
#print(employee_file.read()) #Space out from the line.
#print(employee_file.readlines()) # Read the 1st line only.
# If we input the same line then it show the output the next line
#print(employee_file.readlines()[1]) #index position
for employee in employee_file.readlines():
    print(employee) #printing out each line.

print("____________________")


employee_file.close() #----close the file
