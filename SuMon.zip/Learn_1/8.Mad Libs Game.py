
color = input("Enter a Color: ")
plural_noun = input("Enter a Plural Noun: ")
collis = input("Enter your Collis Name: ")

print("Roses are " + color)
print(plural_noun + " are beautiful")
print("I love " + collis)

