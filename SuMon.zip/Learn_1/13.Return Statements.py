
def cube(num):
    return num * num * num
    print(cube(3))
    print(This_line_will_not_be_printed)
    print(Because_of_it_is_entered_after_return_statement)
    #This line will not be display because this
    #line put after the return statement

print(cube(3))

result = cube(4)
print(result)

def cube1(num):
    return num+num*num
    print("code")

print(cube(5))
print(cube1(5))