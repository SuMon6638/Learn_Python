from Student_32 import Student

student1 = Student("Sumon", "B.Sc", 3.9)
student2 = Student("Anik", "B.Sc", 3.1)

print(student1.on_honor_roll())
print(student2.on_honor_roll())

