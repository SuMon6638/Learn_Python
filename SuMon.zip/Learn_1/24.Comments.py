
# This line will not be shown.
'''
kjskladjfj
lkjhsdkalfja
lkjslkdjf
Multiple line comments
'''
# tag using is better than quotation mark

print("Comments are fun!")